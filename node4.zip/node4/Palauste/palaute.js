import express from "express";

import config from "/config.json" with { type: "json" };
import palautteet from "/palaute.json" with { type: "json" };

const { port, host } = config;

const app = express();
